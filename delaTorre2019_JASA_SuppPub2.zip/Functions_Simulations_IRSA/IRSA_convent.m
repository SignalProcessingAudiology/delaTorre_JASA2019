%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi,t_run,t_iter] = IRSA_convent(y,m,I,J,alpha,OUTPUT)
% IRSA conventional: iterative with synchronized average
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     I (Number of iterations)
%                     J (Length of the averaging window in samples)
%                     alpha (Convergence-control parameter)
%                     OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
%                     t_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2018
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi,t_run,t_iter] = IRSA_convent(y,m,I,J,alpha,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
K = length(m);       % Number of stimuli
xi = zeros(J,1);     % AEP initialization
z = zeros(J,1);                   % Residual initialization
for k=1:K                         % Loop for stimuli
    Sweep = m(k):(m(k)+J-1);      % Sweep selection
    z = z + y(Sweep)/K;           % Average of EEG
end
% Iterations
t_iter=toc;          % time-stamp for iterations
for i=1:I            % loop for iterations
    xi = xi+alpha*z;                  % AEP estimate
    % Residual EEG
    r = y;                            % Residual initialization
    for k=1:K                         % Loop for stimuli
        Sweep = m(k):(m(k)+J-1);      % Sweep selection
        r(Sweep) = r(Sweep)-xi;       % Removes all AEPs from y(n) to obtain residual
    end    
    % Averaged residual estimate
    z = zeros(J,1);                   % Residual initialization
    for k=1:K                         % Loop for stimuli
        Sweep = m(k):(m(k)+J-1);      % Sweep selection
        z = z + r(Sweep)/K;           % Average residual estimation
    end    
    if OUTPUT==1
        fprintf('Iteration %d:   res: %.16f\n',i,std(z)); 
    end
end
t_run=toc;               % total execution time
t_iter=(t_run-t_iter)/I; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%