%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run] = RSLSD_inf(y,m,J)
% Randomized Stimulation with Least Squares Deconvolution: direct
% deconvolution (infinite iterations) with matrix inversion
%     xi =  Rs^(-1) z0         xi = Rs\z0;
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     J (Length of the averaging window in samples)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2019
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run] = RSLSD_inf(y,m,J)
% Initialization
tic;                 % time-stamp beginning of function
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0=zeros(J,1); rs0=zeros(J,1); s=zeros(size(y)); Rs=zeros(J,J);
s(m)=1;              % stimulation signal
for j=1:J
    idx=j+m-1;
    z0(j)=sum(y(idx));  % cross-corr between EEG and stim. signal
    rs0(j)=sum(s(idx)); % autocorrelation of stim. signal
end
z0=z0/Es;               % first averaged response
rs0=rs0/Es;             % normalized autocorrelation stim. signal
for i=1:J
    j=1:J; idx=abs(j-i)+1;
    Rs(i,j)=rs0(idx); % autocorrelation matrix
end
xi=(Rs\z0);           % direct deconvolution by matrix inversion
t_run=toc;            % total execution time
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%