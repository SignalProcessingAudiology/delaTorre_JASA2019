%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run,t_iter] = IRSA_matrix_fft(y,m,I,J,alpha,OUTPUT)
% IRSA, matrix implementation with matrix product in fft domain
%    (this is possible because Rs is a Toeplitz-symmetric matrix)
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     I (Number of iterations)
%                     J (Length of the averaging window in samples)
%                     alpha (Convergence-control parameter)
%                     OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
%                     t_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2019
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run,t_iter] = IRSA_matrix_fft(y,m,I,J,alpha,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0=zeros(J,1); rs0=zeros(J,1); s=zeros(size(y));
s(m)=1;              % stimulation signal
for j=1:J
    idx=j+m-1;
    z0(j)=sum(y(idx));  % cross-corr between EEG and stim. signal
    rs0(j)=sum(s(idx)); % autocorrelation of stim. signal
end
z0=z0/Es;               % first averaged response
rs0=rs0/Es;             % normalized autocorrelation stim. signal
RS=real(fft([rs0; 0; flipud(rs0(2:end))]));  % FT of autocorrelation 
Z0=fft([z0; zeros(J,1)]);              % FT of z0
Zi=Z0; Xi=zeros(2*J,1);                % FT of zi and xi initialization
% Iterations
t_iter=toc;          % time-stamp for iterations
for i=1:I            % loop for iterations
    Xi=Xi+alpha*Zi;    % AEP estimate in freq. domain
    P=RS.*Xi;          % matrix product in freq. domain
    P1=real(ifft(P));  % this two lines are important in order to truncate 
    P=fft([P1(1:J); zeros(J,1)]); % the estimation of the P in time domain
    Zi=Z0-P;    
    if OUTPUT==1
        fprintf('Iteration %d:   res: %.16f\n',i,std(real(Zi))); 
    end
end
xi=real(ifft(Xi));    % the result is transformed to time domain
xi=xi(1:J);           % ...and truncated to remove the non-causal part
t_run=toc;               % total execution time
t_iter=(t_run-t_iter)/I; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
