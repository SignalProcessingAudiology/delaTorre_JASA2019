%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% script_simuation_IRSA.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script compares different IRSA implementations with a simulated EAP
% experiment
% The execution of this script requires the following functions:
%      IRSA_convent.m       IRSA conventional implementation
%      IRSA_matrix.m        IRSA matrix-based implementation
%      IRSA_matrix_opt.m    similar to previous, optimized initialization 
%      IRSA_matrix_fft.m    similar to previous, matrix products with FFT
%      IRSA_matrix_fft_fast.m similar, optimum alpha, convergence check 
%      RSLSD_iter.m         iterative version RSLSD, equivalent to IRSA
%      RSLSD_inf.m          RSLSD at convergence (infinite number of iter.)
% And additionally, a response used for the simulation
%      response_30_60_subj1.mat
% It requires signal processing toolbox
% For Octave users, run:
%          pkg load signal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear,clc; 

%% Configuration parameters for simulation
fs=14700;          % sampling rate 14700 Hz
NOISE_GAIN=2;      % noise level
%J=round(1000e-3*fs);   % length of the response 14700, for 1 second
J=round(200e-3*fs);    % length of the response: 2940 for 200 ms
isi_min=30e-3; % 30 ms
isi_max=60e-3; % 60 ms
%n_stim=15200;  % number of stimuli 15200
n_stim=500;    % number of stimuli 200
N_iter=20;    % number of iterations
alpha=0.05;    % convergence parameter
OUTPUT_IRSA=1; % flag for reporing algorithm evolution
CONVERG_CRITERION=120; % convergence criterion for IRSA_matrix_fft_fast, 120 dB

%% Stimulation sequence
isi=rand(n_stim,1)*(isi_max-isi_min)+isi_min; % random distribution of isi, uniform
stim_ind = round(cumsum(isi)*fs); % indexes of stimulus start
N=max(stim_ind)+fs; % number of samples
s=zeros(N,1);
s(stim_ind)=1;

%% Response to be used in simulation (response to be estimated)
load('response_30_60_subj1.mat');
x(J+1)=0; x=x(1:J); % this guarantees a response length equal to J
t_plot=(0:(J-1))/fs;
figure(1)
semilogx(t_plot*1000,x); xlabel('time (ms)'); ylabel('amplitude');
title('Response to be estimated (time log-scaled)'); 
grid on; xlim([0.1 1000*J/fs]);
figure(2)
plot(t_plot*1000,x); xlabel('time (ms)'); ylabel('amplitude');
title('Response to be estimated (time in linear scale)'); 
grid on; xlim([0 1000*J/fs]);

%% Simulation of EEG: y=s*x+noise
y0=filter(x,1,s);
y=y0+randn(size(y0))*std(y0)*NOISE_GAIN;
SNR_EEG=10*log10(var(y0)/var(y-y0));
figure(3)
t_plotN=(0:(N-1))/fs;
figure(3)
plot(t_plotN,y); xlabel('time (s)'); ylabel('amplitude'); 
title(sprintf('EEG     (SNR-EEG: %.2f dB)',SNR_EEG))
figure(4)
plot(t_plotN,y); xlim([0 1])
xlabel('time (s)'); ylabel('amplitude'); 
title(sprintf('EEG (first second)     (SNR-EEG: %.2f dB)',SNR_EEG))

%% Deconvolution (with predefined alpha and number of iterations)
fprintf('Running conventional IRSA....\n')
[x1,t_run1]    = IRSA_convent(y,stim_ind,N_iter,J,alpha,OUTPUT_IRSA);
fprintf('Running matrix-based IRSA....\n')
[x2,t_run2]     = IRSA_matrix(y,stim_ind,N_iter,J,alpha,OUTPUT_IRSA);
fprintf('Running matrix-based IRSA, optimized initialization....\n')
[x3,t_run3] = IRSA_matrix_opt(y,stim_ind,N_iter,J,alpha,OUTPUT_IRSA);
fprintf('Running matrix-based IRSA, FFT-based matrix product....\n')
[x4,t_run4] = IRSA_matrix_fft(y,stim_ind,N_iter,J,alpha,OUTPUT_IRSA);
fprintf('Running RSLSD iterative (geometric series of matrices)....\n')
[x5,t_run5]      = RSLSD_iter(y,stim_ind,N_iter,J,alpha,OUTPUT_IRSA);
% Deconvolution at convergence
fprintf('Running matrix-based IRSA, fast implementation....\n')
[x6,t_run6] = IRSA_matrix_fft_fast(y,stim_ind,10000,CONVERG_CRITERION,J,OUTPUT_IRSA);
fprintf('Running RSLSD at convergence (direct RSLSD for infinite iterations)....\n')
[x7,t_run7] = RSLSD_inf(y,stim_ind,J);
fprintf('\n--------END OF IRSA/RSLSD ALGORITHMS---------------\n\n')

%% Results: figure
figure(5)
semilogx(t_plot*1000,[x+4.5 x7+3.5 x6+3 x5+2 x4+1.5 x3+1 x2+0.5 x1 ]); 
xlabel('time (ms)'); ylabel('amplitude');
title('Estimated responses');
legend('Response','RSLSD-convergence','IRSA-fast','RSLSD-iter','IRSA-matrix-fft',...
    'IRSA-matrix-opt','IRSA-matrix','IRSA-conventional');
legend('Location','eastoutside');
grid on; xlim([1 1000*J/fs]);

%% Results: difference among responses
% SNR using real response as reference
SNR1_a=10*log10(var(x)/var(x1-x)); SNR2_a=10*log10(var(x)/var(x2-x));
SNR3_a=10*log10(var(x)/var(x3-x)); SNR4_a=10*log10(var(x)/var(x4-x));
SNR5_a=10*log10(var(x)/var(x5-x)); SNR6_a=10*log10(var(x)/var(x6-x));
SNR7_a=10*log10(var(x)/var(x7-x));
% SNR using RSLSD-converg as reference
SNR1_b=10*log10(var(x)/var(x1-x7)); SNR2_b=10*log10(var(x)/var(x2-x7));
SNR3_b=10*log10(var(x)/var(x3-x7)); SNR4_b=10*log10(var(x)/var(x4-x7));
SNR5_b=10*log10(var(x)/var(x5-x7)); SNR6_b=10*log10(var(x)/var(x6-x7));
% SNR using IRSA-convenctional as reference
SNR2_c=10*log10(var(x1)/var(x2-x1)); SNR3_c=10*log10(var(x)/var(x3-x1));
SNR4_c=10*log10(var(x1)/var(x4-x1)); SNR5_c=10*log10(var(x)/var(x5-x1));
SNR6_c=10*log10(var(x)/var(x6-x1)); SNR7_c=10*log10(var(x)/var(x7-x1));
fprintf('SNR of estimated responses, using real response as reference:\n')
fprintf('  IRSA-conv:      %.2f dB\n  IRSA-matr:      %.2f dB\n  IRSA-matr-opt:  %.2f dB\n',...
    SNR1_a,SNR2_a,SNR2_a);
fprintf('  IRSA-matr-fft:  %.2f dB\n  RSLSD-iter:     %.2f dB\n',SNR4_a,SNR5_a);
fprintf('  IRSA-matr-fast: %.2f dB\n  RSLSD-converg:  %.2f dB\n\n',SNR6_a,SNR7_a);
fprintf('SNR of estimated responses, using RSLSD-converg response as reference:\n')
fprintf('  IRSA-conv:      %.2f dB\n  IRSA-matr:      %.2f dB\n  IRSA-matr-opt:  %.2f dB\n',...
    SNR1_b,SNR2_b,SNR2_b);
fprintf('  IRSA-matr-fft:  %.2f dB\n  RSLSD-iter:     %.2f dB\n',SNR4_b,SNR5_b);
fprintf('  IRSA-matr-fast: %.2f dB\n\n',SNR6_b);
fprintf('SNR of estimated responses, using IRSA-convent response as reference:\n')
fprintf('  IRSA-matr:      %.2f dB\n  IRSA-matr-opt:  %.2f dB\n',SNR2_c,SNR2_c);
fprintf('  IRSA-matr-fft:  %.2f dB\n  RSLSD-iter:     %.2f dB\n',SNR4_c,SNR5_c);
fprintf('  IRSA-matr-fast: %.2f dB\n  RSLSD-converg:  %.2f dB\n\n',SNR6_c,SNR7_c);
fprintf('Total execution time:\n')
fprintf('  IRSA-conv:      %.5f s\n  IRSA-matr:      %.5f s\n',t_run1,t_run2);
fprintf('  IRSA-matr-opt:  %.5f s\n  IRSA-matr-fft:  %.5f s\n',t_run3,t_run4);
fprintf('  RSLSD-iter:     %.5f s\n  IRSA-matr-fast: %.5f s\n',t_run5,t_run6);
fprintf('  RSLSD-converg:  %.5f s\n\n',t_run7);


return
