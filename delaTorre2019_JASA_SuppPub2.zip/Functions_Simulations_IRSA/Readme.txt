Matrix-based formulation of the iterative randomized stimulation and averaging (IRSA) method for recording evoked potentials
Angel de la Torre, Joaquin T Valderrama, Jose C Segura, Isaac M Alvarez


INSTRUCTIONS TO RUN A SIMULATION WITH THE SUPPLEMENTARY MATERIAL

Step 1. Download the "SuppPub2.zip" from the URL presented at the end of the paper.

Step 2. Unzip the "SuppPub2.zip" file to a specific directory, e.g. Desktop.

Step 3. In the "Functions_Simulations_IRSA" folder, you will find:

- 7 files that implement the different versions of the IRSA and RSLSD algorithms described in the paper. These files present a format "IRSA_XXXX.m" or "RSLSD_XXXX.m". These files should not be modified.

- 1 file "response_30_60_subj1.mat" that contains an example of an AEP, including ABR, MLR, and CAEP components. This file should not be modified.

- 1 file "script_simulation_IRSA.m" that implements different types of simulations. This script reads the "response_30_60_subj1.mat" file, synthesizes an EEG, adds noise, and estimates the AEP using different IRSA and RSLSD functions. 

Step 4. Open and run the "script_simulation_IRSA.m" script in Matlab or GNU Octave. 

- Please note that in Octave, it is required to load the signal processing package before running the script. You can do this by executing the following command: "pkg load signal".

Step 5. The user is encouraged to run the simulations and modify the different variables (e.g. noise level, length of the response, maximum and minimum ISI, alpha value, etc.) to observe the effect on the deconvolution.

- Please note that the outcome of the simulations provided by this script may not match exactly the results presented in the paper due to the random nature of synthesized noise.

GNU Octave is a high-level language intended for numerical computations with a similar synthax as Matlab. GNU Octave is a freely redistributable software, and can be downloaded from the following website: https://www.gnu.org/software/octave/.

For questions and comments about these functions and scripts, please contact Dr Angel de la Torre Vega (atv@ugr.es) or Dr Joaquin T Valderrama (joaquin.valderrama@nal.gov.au).