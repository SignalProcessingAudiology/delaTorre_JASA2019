%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run,t_iter] = RSLSD_iter(y,m,I,J,alpha,OUTPUT)
% Randomized Stimulation with Least Squares Deconvolution: matrix
% implementation using geometric series of matrices, until iteration i
%     xi = (I-(I-alpha Rs)^i) * Rs^(-1) * z0
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     I (Number of iterations)
%                     J (Length of the averaging window in samples)
%                     alpha (Convergence-control parameter)
%                     OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
%                     t_run_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2019
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run,t_iter] = RSLSD_iter(y,m,I,J,alpha,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0=zeros(J,1); rs0=zeros(J,1); s=zeros(size(y)); Rs=zeros(J,J);
s(m)=1;              % stimulation signal
for j=1:J
    idx=j+m-1;
    z0(j)=sum(y(idx));  % cross-corr between EEG and stim. signal
    rs0(j)=sum(s(idx)); % autocorrelation of stim. signal
end
z0=z0/Es;               % first averaged response
rs0=rs0/Es;             % normalized autocorrelation stim. signal
for i=1:J
    j=1:J; idx=abs(j-i)+1;
    Rs(i,j)=rs0(idx); % autocorrelation matrix
end
xia=(Rs\z0);          % xia = Rs^(-1) z0
A=eye(J)-alpha*Rs;   % A = (I - alpha Rs)
xib=xia;
% Iterations
t_iter=toc;          % time-stamp for iterations
for i=1:I
    xib=A*xib;       %    (I-alpha Rs)^i * Rs^(-1) * z0
    if OUTPUT==1
        fprintf('Iteration %d:   res: %.16f\n',i,std(xib));
    end
end
xi=xia-xib;
t_run=toc;               % total execution time
t_iter=(t_run-t_iter)/I; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%