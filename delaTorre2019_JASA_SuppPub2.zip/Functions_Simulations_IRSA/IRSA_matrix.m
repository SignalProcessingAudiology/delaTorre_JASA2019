%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run,t_iter] = IRSA_matrix(y,m,I,J,alpha,OUTPUT)
% IRSA, matrix implementation:
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     I (Number of iterations)
%                     J (Length of the averaging window in samples)
%                     alpha (Convergence-control parameter)
%                     OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
%                     t_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2018
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run,t_iter] = IRSA_matrix(y,m,I,J,alpha,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
% Initialization of z0 and x0
s=zeros(size(y));    % stimulation signal
s(m)=1;
Es=sum(s.*s);        % energy of the stimulation signal (number of stimuli)
z_tmp=xcorr(y,s,J-1)/Es; % cross-correlation between EEG and stim. signal
z0=z_tmp(J:end);   % z0 is the first averaged response
xi=zeros(J,1);     % initial estimation of the response
zi=z0;
% Initialization of autocorrelation matrix
rs=xcorr(s,J)/Es;  % autocorrelation function of the stimulation signal
Rs=zeros(J,J);     % autocorrelation matrix
for i=1:J
    j=1:J; idx=j-i+J+1;
    Rs(i,j)=rs(idx); % autocorrelation matrix
end
% Iterations
t_iter=toc;          % time-stamp for iterations
for i=1:I            % loop for iterations
    xi=xi+alpha*zi;  % AEP estimate
    zi=z0-Rs*xi;     % Average residual estimation
    if OUTPUT==1
        fprintf('Iteration %d:   res: %.16f\n',i,std(zi)); 
    end
end
t_run=toc;           % total execution time
t_iter=(t_run-t_iter)/I; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%